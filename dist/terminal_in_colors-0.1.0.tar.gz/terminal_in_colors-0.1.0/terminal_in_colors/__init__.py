"""
Classes exported by this package:

- `ColorTerminal`: Class that provides methods to create formatted, colored sentences.
- `info_colors`: Dictionary that provides information of 256 colors to class ColorTerminal.
"""
